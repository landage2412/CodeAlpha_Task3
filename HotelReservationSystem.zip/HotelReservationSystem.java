package HotelReservationSystem;

import java.io.*;
import java.util.*;

class Room {
    int roomNumber;
    String category;
    double price;
    boolean isBooked;

    Room(int roomNumber, String category, double price) {
        this.roomNumber = roomNumber;
        this.category = category;
        this.price = price;
        this.isBooked = false;
    }

    public String toString() {
        return "Room " + roomNumber + " (" + category + ") - $" + price + " per night | " 
                + (isBooked ? "Booked" : "Available");
    }
}

class Reservation {
    String guestName;
    Room room;
    int nights;
    double totalAmount;

    Reservation(String guestName, Room room, int nights) {
        this.guestName = guestName;
        this.room = room;
        this.nights = nights;
        this.totalAmount = room.price * nights;
    }

    public String toString() {
        return "Reservation for " + guestName + " | Room " + room.roomNumber + " (" + room.category + ") | Nights: " 
                + nights + " | Total: $" + totalAmount;
    }
}

class Hotel {
    List<Room> rooms = new ArrayList<>();
    List<Reservation> reservations = new ArrayList<>();

    Hotel() {
        
        rooms.add(new Room(101, "Standard", 100));
        rooms.add(new Room(102, "Standard", 100));
        rooms.add(new Room(201, "Deluxe", 200));
        rooms.add(new Room(202, "Deluxe", 200));
        rooms.add(new Room(301, "Suite", 350));
    }

    void displayAvailableRooms() {
        System.out.println("\n===== Available Rooms =====");
        for (Room r : rooms) {
            if (!r.isBooked) System.out.println(r);
        }
    }

    Reservation bookRoom(String guestName, String category, int nights) {
        for (Room r : rooms) {
            if (!r.isBooked && r.category.equalsIgnoreCase(category)) {
                r.isBooked = true;
                Reservation res = new Reservation(guestName, r, nights);
                reservations.add(res);
                System.out.println("✅ Payment Successful! Booking Confirmed.");
                return res;
            }
        }
        System.out.println("❌ No available rooms in " + category + " category.");
        return null;
    }

    void cancelReservation(String guestName) {
        Iterator<Reservation> it = reservations.iterator();
        while (it.hasNext()) {
            Reservation res = it.next();
            if (res.guestName.equalsIgnoreCase(guestName)) {
                res.room.isBooked = false;
                it.remove();
                System.out.println("✅ Reservation cancelled for " + guestName);
                return;
            }
        }
        System.out.println("❌ No reservation found for " + guestName);
    }

    void viewReservations() {
        System.out.println("\n===== All Reservations =====");
        for (Reservation res : reservations) {
            System.out.println(res);
        }
    }

    void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("reservations.dat"))) {
            oos.writeObject(new ArrayList<>(reservations));
            System.out.println("💾 Reservations saved to file.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("reservations.dat"))) {
            reservations = (ArrayList<Reservation>) ois.readObject();
            for (Reservation r : reservations) {
                r.room.isBooked = true;
            }
            System.out.println("📂 Reservations loaded from file.");
        } catch (Exception e) {
            System.out.println("No saved reservations found.");
        }
    }
}

public class HotelReservationSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Hotel hotel = new Hotel();
        hotel.loadFromFile(); 
        int choice;
        do {
            System.out.println("\n===== Hotel Reservation Menu =====");
            System.out.println("1. View Available Rooms");
            System.out.println("2. Book a Room");
            System.out.println("3. Cancel Reservation");
            System.out.println("4. View All Reservations");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    hotel.displayAvailableRooms();
                    break;
                case 2:
                    System.out.print("Enter your name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter room category (Standard/Deluxe/Suite): ");
                    String category = sc.nextLine();
                    System.out.print("Enter number of nights: ");
                    int nights = sc.nextInt();
                    hotel.bookRoom(name, category, nights);
                    break;
                case 3:
                    System.out.print("Enter guest name to cancel: ");
                    String cancelName = sc.nextLine();
                    hotel.cancelReservation(cancelName);
                    break;
                case 4:
                    hotel.viewReservations();
                    break;
                case 5:
                    hotel.saveToFile();
                    System.out.println("Exiting... Thank you for using Hotel Reservation System!");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 5);

        sc.close();
    }
}
